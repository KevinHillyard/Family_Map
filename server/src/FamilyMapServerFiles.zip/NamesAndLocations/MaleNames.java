package NamesAndLocations;

/**
 * Class to load the male names into from the json file.
 */
public class MaleNames {
    public String[] data;
}
