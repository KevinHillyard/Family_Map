package NamesAndLocations;

/**
 * Class to load the female names into from the json file.
 */
public class FemaleNames {
    public String[] data;
}
