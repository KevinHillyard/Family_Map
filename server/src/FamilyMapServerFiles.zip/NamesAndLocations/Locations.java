package NamesAndLocations;

/**
 * Class to load the locations into from the json file.
 */
public class Locations {
    public Locations[] data;
    public String country;
    public String city;
    public double latitude;
    public double longitude;
}
