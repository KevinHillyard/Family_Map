package NamesAndLocations;

/**
 * Class to load the surnames into from the json file.
 */
public class Surnames {
    public String[] data;
}
